<!-- Footer -->
<footer class="main">
	&copy; 2017 <strong>Ekattor School Manager | Version 5.1.1</strong>.
    Developed by
	<a href="http://creativeitem.com"
    	target="_blank">Creativeitem</a>
</footer>
