<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config = array(
    'username'                  => 'express_soc',
    'apiKey'    => 'd7e71f267c811bbaf728c92f2c237f58fc09b20432270eea48406bfeb99509c8',
    'default_country_code'      => '+254',
    'sms_sender'                => NULL            //Leave as NULL to send using the default senderId 'AFRICASTKNG'
    );