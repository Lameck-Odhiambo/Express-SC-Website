
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/vendor/popper.min.js"></script>
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/scripts.js"></script>
<script src="<?php echo base_url();?>assets/frontend/<?php echo $theme;?>/js/jquery.magnific-popup.min.js"></script>
